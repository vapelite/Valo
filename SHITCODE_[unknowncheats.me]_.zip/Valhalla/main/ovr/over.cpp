#include <ovr/overlay.h>

CurrentProcess Process = {};
OverlayWindow Overlay = {};
DirectX9Interface DirectX9 = {
	nullptr, nullptr, {}, {-1}, {0}
};


auto createwindow() -> bool
{
	SPOOF_FUNC;

	Overlay.Hwnd = FindWindowA(("Chrome_WidgetWin_1"), ("Discord Overlay"));

	if (!Overlay.Hwnd)
	{
		system("cls");
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
		MessageBoxA(0, ("Failed To Find Discord."), ("Overlay"), MB_OK);
		Sleep(5000);
		exit(1);
		return false;
	}

	ShowWindow(Overlay.Hwnd, SW_SHOW);

	SetWindowLongA(Overlay.Hwnd, GWL_EXSTYLE, WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_LAYERED);
	SetWindowLongA(
		Overlay.Hwnd,
		-20,
		static_cast<LONG_PTR>(
			static_cast<int>(GetWindowLongA(Overlay.Hwnd, -20)) | 0x20
			)
	);

	MARGINS margin = { -1, -1, -1, -1 };
	DwmExtendFrameIntoClientArea(
		Overlay.Hwnd,
		&margin
	);

	SetLayeredWindowAttributes(
		Overlay.Hwnd,
		NULL,
		0xFF,
		0x02
	);

	SetWindowPos(
		Overlay.Hwnd,
		0,
		0, 0, 0, 0,
		0x0002 | 0x0001
	);



	UpdateWindow(Overlay.Hwnd);
	HWND(overlaywindow);
	return true;
}

auto dx9() -> bool
{
	SPOOF_FUNC;
	if (FAILED(Direct3DCreate9Ex(D3D_SDK_VERSION, &DirectX9.IDirect3D9))) {
		return false;
	}

	D3DPRESENT_PARAMETERS Params = { 0 };
	Params.Windowed = TRUE;
	Params.SwapEffect = D3DSWAPEFFECT_DISCARD;
	Params.hDeviceWindow = Overlay.Hwnd;
	Params.MultiSampleQuality = D3DMULTISAMPLE_NONE;
	Params.BackBufferFormat = D3DFMT_A8R8G8B8;
	Params.BackBufferWidth = Width;
	Params.BackBufferHeight = Height;
	Params.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
	Params.EnableAutoDepthStencil = TRUE;
	Params.AutoDepthStencilFormat = D3DFMT_D16;
	if (FAILED(DirectX9.IDirect3D9->CreateDeviceEx(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, Overlay.Hwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING, &Params, 0, &DirectX9.pDevice))) {
		DirectX9.IDirect3D9->Release();
		return false;
	}

	if (!DirectX9.pDevice)
		return false;


	IMGUI_CHECKVERSION();
	ImGui::CreateContext();

	ImGuiIO& io = ImGui::GetIO(); (void)io;
	io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

	io.IniFilename = NULL; // Disable .ini file  

	io.FontDefault = io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/consola.ttf", 13.0f);

	ImGui::StyleColorsDark();

	ImGui_ImplWin32_Init(Overlay.Hwnd);
	ImGui_ImplDX9_Init(DirectX9.pDevice);
	DirectX9.IDirect3D9->Release();


	return true;
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WinProc(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam) {
	if (ImGui_ImplWin32_WndProcHandler(hWnd, Message, wParam, lParam))
		return true;

	switch (Message) {
	case WM_DESTROY:
		if (DirectX9.pDevice != NULL) {
			DirectX9.pDevice->EndScene();
			DirectX9.pDevice->Release();
		}
		if (DirectX9.IDirect3D9 != NULL) {
			DirectX9.IDirect3D9->Release();
		}
		PostQuitMessage(0);
		exit(4);
		break;
	case WM_SIZE:
		if (DirectX9.pDevice != NULL && wParam != SIZE_MINIMIZED) {
			ImGui_ImplDX9_InvalidateDeviceObjects();
			DirectX9.pParameters.BackBufferWidth = LOWORD(lParam);
			DirectX9.pParameters.BackBufferHeight = HIWORD(lParam);
			HRESULT hr = DirectX9.pDevice->Reset(&DirectX9.pParameters);
			if (hr == D3DERR_INVALIDCALL)
				IM_ASSERT(0);
			ImGui_ImplDX9_CreateDeviceObjects();
		}
		break;
	default:
		return DefWindowProc(hWnd, Message, wParam, lParam);
		break;
	}
	return 0;
}