#pragma once
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <Windows.h>
#include <iostream>
#include <string>
#include <Psapi.h>
#include <fstream>
#include <dwmapi.h>
#include <d3d9.h> 
#include <chrono>
#include <thread>
#include <winuser.h>
#include <sstream>
#include <TlHelp32.h>

#include <algorithm>  // for std::sort
#include <cmath>      // for sinf, cosf, M_PI
#include <vector> 

#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx9.h"
#include "imgui/imgui_impl_win32.h"
#include "imgui/imgui_internal.h"

#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "winmm.lib")

#include <km/kernel.h>
#include <km/utils.h>
#include <ovr/overlay.h>
#include <hake/sdk.h>
#include <hake/cache.h>
#include <hake/cheats.h>
#include <loop/valhalla.h>