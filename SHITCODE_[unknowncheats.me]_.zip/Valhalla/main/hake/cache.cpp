#include <hake/cache.h>

uintptr_t uworld = 0;

namespace check {
	uintptr_t guard;

	bool zero_check(uintptr_t pointer)
	{
		constexpr uintptr_t filter = 0xFFFF0000FFFFFF00;
		uintptr_t result = pointer & filter;
		return result == 0x0000000000000000;
	}

	bool extras_check(uintptr_t pointer)
	{
		constexpr uintptr_t filter = 0xFFFF000000000000;
		uintptr_t result = pointer & filter;
		return result == 0x0000000000000000;
	}

	bool is_valid(uintptr_t pointer)
	{
		if (!pointer)
			return false;

		if (zero_check(pointer))
			return false;

		if (!extras_check(pointer))
			return false;

		return true;
	}

	bool is_guarded_2(uintptr_t pointer)
	{

		if (zero_check(pointer))
		{
			return false;
		}

		constexpr uintptr_t filter = 0xFFFFFFFFFF000000;
		uintptr_t result = pointer & filter;
		return result == 0x0000000000000000;
	}

	bool is_guarded(uintptr_t pointer)
	{
		constexpr uintptr_t filter = 0xFFFFFFFF00000000;
		uintptr_t result = pointer & filter;
		return result == 0x8000000000 || result == 0x10000000000;
	}

	uint64_t validate_pointer(uint64_t address)
	{
		if (is_guarded(address))
			return guard + (address & 0xFFFFFF);
		else
			return address;
	}
}

template<typename T>
T safe_rpm(uintptr_t address)
{
	T value = km::RPM<T>(address);
	if (check::is_guarded((uintptr_t)value))
		value = check::validate_pointer((uintptr_t)value);
	return value;
}

namespace cache
{
	void getworld()
	{
		auto pml4_base = utils::find_pml4_base();

		uintptr_t UWOLRD_1 = km::RPM<uintptr_t>(pml4_base + 0x1C0);


		uintptr_t uworld_offset = 0;

		for (int i = 0x0; i < 0x500; i += 0x8)
		{
			uintptr_t address_to_read = pml4_base + i;


			auto potential_uworld = km::RPM<uintptr_t>(address_to_read);



			if (potential_uworld != 0)
			{
				uintptr_t level_address = potential_uworld + offsets::persistent_level;


				auto level = km::RPM<uintptr_t>(level_address);
				if (level != 0)
				{
					uintptr_t owning_world_address = level + offsets::uworld_pointer;


					auto owning_world = km::RPM<uintptr_t>(owning_world_address);



					if (owning_world == potential_uworld)
					{
						uworld = potential_uworld;


						uworld_offset = i;
						break;
					}
				}
			}
		}

		if (uworld_offset == 0)
		{
			printf("[-] Failed to find UWorld offset!\n");
		}
	}

	bool thread_running = false;

	void start_uworld()
	{
		auto last_update = std::chrono::steady_clock::now();
		int iteration_count = 0;

		while (true)
		{
			auto now = std::chrono::steady_clock::now();
			auto time_t = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());

			auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - last_update).count();

			if (!uworld || elapsed > 15) {
				getworld();
				last_update = now;
			}
			std::this_thread::sleep_for(std::chrono::milliseconds(1000));
		}
	}


	void cache()
	{
		while (true)
		{
			if (km::hvci_enabled == true)
			{
				km::base = utils::get_process_base_id(km::process_id);

				constexpr uint64_t uworldState = 0x9EF4050;
				uworld = km::RPM<uintptr_t>(km::base + uworldState);
			}
			else
			{
				if (!thread_running)
				{
					std::thread(start_uworld).detach();
					thread_running = true;
				}
			}

			uintptr_t game_instance = km::RPM<uintptr_t>(uworld + offsets::game_instance);

			uintptr_t game_state = km::RPM<uintptr_t>(uworld + offsets::gamestate);
			uintptr_t level = km::RPM<uintptr_t>(uworld + offsets::persistent_level);

			// Local player
			uintptr_t local_player_array = km::RPM<uintptr_t>(game_instance + offsets::localplayers_array);
			uintptr_t local_player = km::RPM<uintptr_t>(local_player_array);

			uintptr_t player_controller = km::RPM<uintptr_t>(local_player + offsets::player_controller);
			uintptr_t local_pawn = km::RPM<uintptr_t>(player_controller + offsets::acknowledge_pawn);

			uintptr_t player_state = km::RPM<uintptr_t>(local_pawn + offsets::player_state);
			uintptr_t localmesh = km::RPM<uintptr_t>(player_state + offsets::mesh);
			uintptr_t team_component = km::RPM<uintptr_t>(player_state + offsets::team_component);
			double local_team_id = km::RPM<double>(team_component + offsets::team_id);

			Cache::cameraManager = km::RPM<uintptr_t>(player_controller + offsets::player_camera_manager);
			get_view();

			// Arrays
			auto player_state_array = km::RPM<TArray<uintptr_t>>(game_state + offsets::player_state_array);
			if (!player_state_array.Length() || player_state_array.Length() > 15)
				player_state_array = {};

			auto actor_array = km::RPM<TArray<uintptr_t>>(level + offsets::actor_array);

			// Actor count
			Cache::actorcount = km::RPM<INT32>(level + offsets::actors_count);

			Cache::peoplecount = km::RPM<int>(game_state + (offsets::player_state_array + sizeof(uintptr_t)));


			playerCache.clear();
			playerCache.reserve(Cache::actorcount);

			// Loop through actors
			for (int i = 0; i < Cache::actorcount; i++)
			{
				uintptr_t actor = km::RPM<uintptr_t>(actor_array.GetAddress() + (i * 0x8));
				if (!actor) continue;



				// Team check
				uintptr_t actor_team_component = km::RPM<uintptr_t>(actor + offsets::team_component);
				int actor_team_id = km::RPM<double>(actor_team_component + offsets::team_id);
				if (settings::teamcheck)
				{
					if (actor_team_id == local_team_id) continue;
				}

				INT32 unique_id = km::RPM<INT32>(actor + 0x38);
				if (unique_id != 18743553) continue;


				// Health
				uintptr_t damage_handler = km::RPM<uintptr_t>(actor + offsets::damage_handler);
				if (!damage_handler) continue;

				float health = km::RPM<float>(damage_handler + offsets::health);
				if (health <= 0) continue;

				// Mesh & bones
				uintptr_t mesh = km::RPM<uintptr_t>(actor + offsets::mesh);
				if (!mesh) continue;

				if (mesh == localmesh)
					continue;

				uintptr_t skelmesh = km::RPM<uintptr_t>(mesh + offsets::BoundsScale);

				double bone_count = km::RPM<double>(skelmesh + offsets::bone_count);

				uintptr_t bone_array = km::RPM<uintptr_t>(mesh + offsets::bone_array);
				if (!bone_array)
					bone_array = km::RPM<uintptr_t>(mesh + offsets::bone_array_cache);

				if (!bone_array) continue;

				// Bone positions
				fvector head = bone_matrix(8, bone_array, mesh);
				fvector root = bone_matrix(0, bone_array, mesh);

				FVector2D head_screen = w2s(head);
				FVector2D root_screen = w2s(root);

				// Draw circle on head
				Player player{};
				player.actor = actor;
				player.mesh = mesh;
				player.damageHandler = damage_handler;
				player.teamComponent = actor_team_component;
				player.teamId = actor_team_id;
				player.health = health;
				player.headPos = head;
				player.rootPos = root;
				player.bone_count = bone_count;
				player.valid = true;
				player.bone_array = bone_array;

				// Push to cache
				std::lock_guard<std::mutex> lock(cacheMutex);
				playerCache.push_back(player);
			}
		}
	}
}
