#pragma once
#include <includes.h>
#include "offsets.hpp"
#include <mutex>

#define M_PI (float)3.1415926535
inline int center_x = GetSystemMetrics(SM_CXSCREEN);
inline int center_y = GetSystemMetrics(SM_CYSCREEN);

class fvector {
public:
    fvector() : x(0.0), y(0.0), z(0.0) {}
    fvector(double _x, double _y, double _z) : x(_x), y(_y), z(_z) {}
    ~fvector() {}

    double x;
    double y;
    double z;

    inline double Dot(const fvector& v) const {
        return x * v.x + y * v.y + z * v.z;
    }

    inline double distance(const fvector& v) const {
        return std::sqrtf(std::powf(v.x - x, 2.0) +
            std::powf(v.y - y, 2.0) +
            std::powf(v.z - z, 2.0));
    }

    fvector operator+(const fvector& v) const {
        return fvector(x + v.x, y + v.y, z + v.z);
    }

    fvector operator-(const fvector& v) const {
        return fvector(x - v.x, y - v.y, z - v.z);
    }

    fvector operator/(double flDiv) const {
        return fvector(x / flDiv, y / flDiv, z / flDiv);
    }

    fvector operator*(double Scale) const {
        return fvector(x * Scale, y * Scale, z * Scale);
    }

    inline double Length() const {
        return sqrtf((x * x) + (y * y) + (z * z));
    }

    fvector& operator-=(const fvector& v) {
        x -= v.x;
        y -= v.y;
        z -= v.z;
        return *this;
    }
};

struct FVector2D {
public:
    double x;
    double y;

    inline FVector2D() : x(0.0), y(0.0) {}
    inline FVector2D(double _x, double _y) : x(_x), y(_y) {}

    inline double Distance(const FVector2D& v) const {
        return sqrtf(((v.x - x) * (v.x - x)) +
            ((v.y - y) * (v.y - y)));
    }

    inline FVector2D operator+(const FVector2D& v) const {
        return FVector2D(x + v.x, y + v.y);
    }

    inline FVector2D operator-(const FVector2D& v) const {
        return FVector2D(x - v.x, y - v.y);
    }
};

struct fquat {
    double x;
    double y;
    double z;
    double w;
};

struct ftransform {
    fquat rot;
    fvector translation;
    char pad[4];
    fvector scale;
    char pad1[4];

    D3DMATRIX ToMatrixWithScale() const {
        D3DMATRIX m;
        m._41 = translation.x;
        m._42 = translation.y;
        m._43 = translation.z;

        double x2 = rot.x + rot.x;
        double y2 = rot.y + rot.y;
        double z2 = rot.z + rot.z;

        double xx2 = rot.x * x2;
        double yy2 = rot.y * y2;
        double zz2 = rot.z * z2;

        m._11 = (1.0 - (yy2 + zz2)) * scale.x;
        m._22 = (1.0 - (xx2 + zz2)) * scale.y;
        m._33 = (1.0 - (xx2 + yy2)) * scale.z;

        double yz2 = rot.y * z2;
        double wx2 = rot.w * x2;
        m._32 = (yz2 - wx2) * scale.z;
        m._23 = (yz2 + wx2) * scale.y;

        double xy2 = rot.x * y2;
        double wz2 = rot.w * z2;
        m._21 = (xy2 - wz2) * scale.y;
        m._12 = (xy2 + wz2) * scale.x;

        double xz2 = rot.x * z2;
        double wy2 = rot.w * y2;
        m._31 = (xz2 + wy2) * scale.z;
        m._13 = (xz2 - wy2) * scale.x;

        m._14 = 0.0;
        m._24 = 0.0;
        m._34 = 0.0;
        m._44 = 1.0;

        return m;
    }
};

inline D3DMATRIX matrix(fvector rot, fvector origin = fvector(0.0, 0.0, 0.0)) {
    auto radPitch = (rot.x * M_PI / 180.0);
    auto radYaw = (rot.y * M_PI / 180.0);
    auto radRoll = (rot.z * M_PI / 180.0);

    auto sp = sinf(radPitch);
    auto cp = cosf(radPitch);
    auto sy = sinf(radYaw);
    auto cy = cosf(radYaw);
    auto sr = sinf(radRoll);
    auto cr = cosf(radRoll);

    D3DMATRIX matrix;
    matrix.m[0][0] = cp * cy;
    matrix.m[0][1] = cp * sy;
    matrix.m[0][2] = sp;
    matrix.m[0][3] = 0.f;

    matrix.m[1][0] = sr * sp * cy - cr * sy;
    matrix.m[1][1] = sr * sp * sy + cr * cy;
    matrix.m[1][2] = -sr * cp;
    matrix.m[1][3] = 0.f;

    matrix.m[2][0] = -(cr * sp * cy + sr * sy);
    matrix.m[2][1] = cy * sr - cr * sp * sy;
    matrix.m[2][2] = cr * cp;
    matrix.m[2][3] = 0.f;

    matrix.m[3][0] = 0.0f;
    matrix.m[3][1] = 0.0f;
    matrix.m[3][2] = 0.0f;
    matrix.m[3][3] = 1.f;

    return matrix;
}

inline D3DMATRIX MatrixMultiplication(D3DMATRIX pM1, D3DMATRIX pM2)
{
	D3DMATRIX pOut;
	pOut._11 = pM1._11 * pM2._11 + pM1._12 * pM2._21 + pM1._13 * pM2._31 + pM1._14 * pM2._41;
	pOut._12 = pM1._11 * pM2._12 + pM1._12 * pM2._22 + pM1._13 * pM2._32 + pM1._14 * pM2._42;
	pOut._13 = pM1._11 * pM2._13 + pM1._12 * pM2._23 + pM1._13 * pM2._33 + pM1._14 * pM2._43;
	pOut._14 = pM1._11 * pM2._14 + pM1._12 * pM2._24 + pM1._13 * pM2._34 + pM1._14 * pM2._44;
	pOut._21 = pM1._21 * pM2._11 + pM1._22 * pM2._21 + pM1._23 * pM2._31 + pM1._24 * pM2._41;
	pOut._22 = pM1._21 * pM2._12 + pM1._22 * pM2._22 + pM1._23 * pM2._32 + pM1._24 * pM2._42;
	pOut._23 = pM1._21 * pM2._13 + pM1._22 * pM2._23 + pM1._23 * pM2._33 + pM1._24 * pM2._43;
	pOut._24 = pM1._21 * pM2._14 + pM1._22 * pM2._24 + pM1._23 * pM2._34 + pM1._24 * pM2._44;
	pOut._31 = pM1._31 * pM2._11 + pM1._32 * pM2._21 + pM1._33 * pM2._31 + pM1._34 * pM2._41;
	pOut._32 = pM1._31 * pM2._12 + pM1._32 * pM2._22 + pM1._33 * pM2._32 + pM1._34 * pM2._42;
	pOut._33 = pM1._31 * pM2._13 + pM1._32 * pM2._23 + pM1._33 * pM2._33 + pM1._34 * pM2._43;
	pOut._34 = pM1._31 * pM2._14 + pM1._32 * pM2._24 + pM1._33 * pM2._34 + pM1._34 * pM2._44;
	pOut._41 = pM1._41 * pM2._11 + pM1._42 * pM2._21 + pM1._43 * pM2._31 + pM1._44 * pM2._41;
	pOut._42 = pM1._41 * pM2._12 + pM1._42 * pM2._22 + pM1._43 * pM2._32 + pM1._44 * pM2._42;
	pOut._43 = pM1._41 * pM2._13 + pM1._42 * pM2._23 + pM1._43 * pM2._33 + pM1._44 * pM2._43;
	pOut._44 = pM1._41 * pM2._14 + pM1._42 * pM2._24 + pM1._43 * pM2._34 + pM1._44 * pM2._44;

	return pOut;
}
	struct FMinimalViewInfo {
		struct fvector Location {};
		struct fvector Rotation {};
		float FOV;
	};

    namespace Cache
    {
        inline uintptr_t cameraManager = 0;
        inline FMinimalViewInfo view;
    }

	inline fvector bone_matrix(int index, uintptr_t array, uintptr_t mesh)
	{
		ftransform comp_to_world = km::RPM<ftransform>(mesh + offsets::component_to_world);
		ftransform bone = km::RPM<ftransform>(array + (index * 0x60));
		D3DMATRIX Matrix;
		Matrix = MatrixMultiplication(bone.ToMatrixWithScale(), comp_to_world.ToMatrixWithScale());

        return fvector(Matrix._41, Matrix._42, Matrix._43);
	}

    inline void get_view()
    {
        Cache::view = km::RPM<FMinimalViewInfo>(
            Cache::cameraManager + offsets::camera_private + 0x10
        );
    }

    inline FVector2D w2s(fvector world_location)
    {
        auto ViewInfo = Cache::view;
        fvector CameraLocation = ViewInfo.Location;
        fvector CameraRotation = ViewInfo.Rotation;

        D3DMATRIX rotation_matrix = matrix(CameraRotation);
        auto& axis_x = rotation_matrix.m[0];
        auto& axis_y = rotation_matrix.m[1];
        auto& axis_z = rotation_matrix.m[2];

        fvector delta = world_location - CameraLocation;

        auto transformed_x = delta.Dot(fvector(axis_y[0], axis_y[1], axis_y[2]));
        auto transformed_y = delta.Dot(fvector(axis_z[0], axis_z[1], axis_z[2]));
        auto transformed_z = max(delta.Dot(fvector(axis_x[0], axis_x[1], axis_x[2])), 1.0f);

        float FovAngle = ViewInfo.FOV;

        float fov_rad = FovAngle * M_PI / 180.0f;
        float fov_tan = tanf(fov_rad / 2.0f);

        int screen_width_center = GetSystemMetrics(0) / 2;
        int screen_height_center = GetSystemMetrics(1) / 2;

        float screen_x = screen_width_center + (transformed_x / fov_tan) * screen_width_center / transformed_z;
        float screen_y = screen_height_center - (transformed_y / fov_tan) * screen_width_center / transformed_z;

        return FVector2D(screen_x, screen_y);
    }

	template<typename T>
	struct TArray
	{
		T* Data;          // pointer to first element
		int32_t Count;    // number of elements
		int32_t Max;      // capacity

		// Returns length of array (same as Count)
		int32_t Length() const
		{
			return Count;
		}

		// Access element by index
		T& operator[](int i)
		{
			return Data[i];
		}

		const T& operator[](int i) const
		{
			return Data[i];
		}

		// Check if index is valid
		bool IsValidIndex(int i) const
		{
			return i >= 0 && i < Count;
		}

		// Returns the raw address of Data
		uintptr_t GetAddress() const
		{
			return reinterpret_cast<uintptr_t>(Data);
		}

		// Clears this TArray wrapper
		void Reset()
		{
			Data = nullptr;
			Count = 0;
			Max = 0;
		}
	};

    struct Player {
        uintptr_t actor;
        uintptr_t mesh;
        uintptr_t damageHandler;
        uintptr_t teamComponent;
        int teamId;
        float health;
        fvector headPos;
        fvector rootPos;
        double bone_count;
        uintptr_t bone_array;

        bool valid;
    };
    inline std::mutex cacheMutex;
    inline std::vector<Player> playerCache;
