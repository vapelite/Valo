#pragma once
#include "cache.h"

namespace final
{
	void espaimloop();
	void aimloop();
}