﻿#include "cheats.h"

void draw_cornered_box(int x, int y, int w, int h, const ImColor color, int thickness)
{
    auto draw = ImGui::GetForegroundDrawList();

    // outline thickness = base + 2
    int outline = thickness + 2;
    ImColor black = ImColor(0, 0, 0, 255);

    // OUTLINE (black, slightly thicker)
    draw->AddLine(ImVec2(x, y), ImVec2(x, y + (h / 3)), black, outline);
    draw->AddLine(ImVec2(x, y), ImVec2(x + (w / 3), y), black, outline);
    draw->AddLine(ImVec2(x + w - (w / 3), y), ImVec2(x + w, y), black, outline);
    draw->AddLine(ImVec2(x + w, y), ImVec2(x + w, y + (h / 3)), black, outline);
    draw->AddLine(ImVec2(x, y + h - (h / 3)), ImVec2(x, y + h), black, outline);
    draw->AddLine(ImVec2(x, y + h), ImVec2(x + (w / 3), y + h), black, outline);
    draw->AddLine(ImVec2(x + w - (w / 3), y + h), ImVec2(x + w, y + h), black, outline);
    draw->AddLine(ImVec2(x + w, y + h - (h / 3)), ImVec2(x + w, y + h), black, outline);

    // MAIN (colored)
    draw->AddLine(ImVec2(x, y), ImVec2(x, y + (h / 3)), color, thickness);
    draw->AddLine(ImVec2(x, y), ImVec2(x + (w / 3), y), color, thickness);
    draw->AddLine(ImVec2(x + w - (w / 3), y), ImVec2(x + w, y), color, thickness);
    draw->AddLine(ImVec2(x + w, y), ImVec2(x + w, y + (h / 3)), color, thickness);
    draw->AddLine(ImVec2(x, y + h - (h / 3)), ImVec2(x, y + h), color, thickness);
    draw->AddLine(ImVec2(x, y + h), ImVec2(x + (w / 3), y + h), color, thickness);
    draw->AddLine(ImVec2(x + w - (w / 3), y + h), ImVec2(x + w, y + h), color, thickness);
    draw->AddLine(ImVec2(x + w, y + h - (h / 3)), ImVec2(x + w, y + h), color, thickness);
}

inline void DrawLine(const FVector2D& p1, const FVector2D& p2, ImU32 color, float thickness = 1.5f)
{
        ImGui::GetBackgroundDrawList()->AddLine(
            ImVec2(p1.x, p1.y),
            ImVec2(p2.x, p2.y),
            color,
            thickness
        );
}

inline void DrawHealthBar(const Player& player, float box_x, float box_y, float box_w, float box_h)
{
    if (player.health <= 0.0f || player.health > 100.0f)
        return;

    float healthPerc = player.health / 100.0f;

    // position bar on the left side of the box
    float barWidth = 4.0f;                   // thickness of the bar
    float barHeight = box_h * healthPerc;     // filled part
    float x = box_x - (barWidth + 2.0f);      // offset a bit to the left
    float y = box_y + (box_h - barHeight);    // bottom aligned

    // background (black)
    ImGui::GetBackgroundDrawList()->AddRectFilled(
        ImVec2(x, box_y),
        ImVec2(x + barWidth, box_y + box_h),
        IM_COL32(0, 0, 0, 200)
    );

    // color gradient (red -> yellow -> green)
    ImU32 healthColor;
    if (healthPerc > 0.6f)
        healthColor = IM_COL32(0, 255, 0, 255);   // green
    else if (healthPerc > 0.3f)
        healthColor = IM_COL32(255, 255, 0, 255); // yellow
    else
        healthColor = IM_COL32(255, 0, 0, 255);   // red

    // filled health
    ImGui::GetBackgroundDrawList()->AddRectFilled(
        ImVec2(x, y),
        ImVec2(x + barWidth, y + barHeight),
        healthColor
    );
}

void DrawChinaHat(fvector headPos, float radius, float height, int segments)
{
    fvector apex = headPos + fvector(0, 0, height);

  
    float hue = fmodf((GetTickCount64() * 0.001f) * 0.25f, 1.0f); // speed control
    ImColor rainbowColor = ImColor::HSV(hue, 1.0f, 1.0f);

    FVector2D apex2D = w2s(apex);

    // Generate circular base of the hat
    for (int i = 0; i < segments; i++)
    {
        float angle1 = (i / (float)segments) * 2 * M_PI;
        float angle2 = ((i + 1) / (float)segments) * 2 * M_PI;

        fvector base1 = headPos + fvector(cos(angle1) * radius, sin(angle1) * radius, 0);
        fvector base2 = headPos + fvector(cos(angle2) * radius, sin(angle2) * radius, 0);

        FVector2D base1_2D = w2s(base1);
        FVector2D base2_2D = w2s(base2);

            ImGui::GetBackgroundDrawList()->AddLine(
                ImVec2(apex2D.x, apex2D.y),
                ImVec2(base1_2D.x, base1_2D.y),
                rainbowColor, 1.5f
            );

            // Draw base ring
            ImGui::GetBackgroundDrawList()->AddLine(
                ImVec2(base1_2D.x, base1_2D.y),
                ImVec2(base2_2D.x, base2_2D.y),
                rainbowColor, 1.0f
            );
    }
}

struct Bones {
    fvector bone_neck, bone_chest, bone_pelvis, bone_rshoulder, bone_relbow, bone_rhand, bone_rthigh, bone_rknee, bone_rfoot, bone_lshoulder, bone_lelbow, bone_lhand, bone_lthigh, bone_lknee, bone_lfoot;
};

inline Bones get_player_bones(const Player& player) {
    Bones bones{};

    if (player.bone_count == 103) // bot
    {
        bones.bone_neck = bone_matrix(9, player.bone_array, player.mesh);

        bones.bone_lshoulder = bone_matrix(33, player.bone_array, player.mesh);
        bones.bone_lelbow = bone_matrix(30, player.bone_array, player.mesh);
        bones.bone_lhand = bone_matrix(32, player.bone_array, player.mesh);

        bones.bone_rshoulder = bone_matrix(58, player.bone_array, player.mesh);
        bones.bone_relbow = bone_matrix(55, player.bone_array, player.mesh);
        bones.bone_rhand = bone_matrix(57, player.bone_array, player.mesh);

        bones.bone_lthigh = bone_matrix(63, player.bone_array, player.mesh);
        bones.bone_lknee = bone_matrix(65, player.bone_array, player.mesh);
        bones.bone_lfoot = bone_matrix(69, player.bone_array, player.mesh);

        bones.bone_rthigh = bone_matrix(77, player.bone_array, player.mesh);
        bones.bone_rknee = bone_matrix(79, player.bone_array, player.mesh);
        bones.bone_rfoot = bone_matrix(83, player.bone_array, player.mesh);
    }
    else if (player.bone_count == 104) // male
    {
        bones.bone_neck = bone_matrix(21, player.bone_array, player.mesh);

        bones.bone_lshoulder = bone_matrix(23, player.bone_array, player.mesh);
        bones.bone_lelbow = bone_matrix(24, player.bone_array, player.mesh);
        bones.bone_lhand = bone_matrix(25, player.bone_array, player.mesh);

        bones.bone_rshoulder = bone_matrix(49, player.bone_array, player.mesh);
        bones.bone_relbow = bone_matrix(50, player.bone_array, player.mesh);
        bones.bone_rhand = bone_matrix(51, player.bone_array, player.mesh);

        bones.bone_lthigh = bone_matrix(77, player.bone_array, player.mesh);
        bones.bone_lknee = bone_matrix(78, player.bone_array, player.mesh);
        bones.bone_lfoot = bone_matrix(80, player.bone_array, player.mesh);

        bones.bone_rthigh = bone_matrix(84, player.bone_array, player.mesh);
        bones.bone_rknee = bone_matrix(85, player.bone_array, player.mesh);
        bones.bone_rfoot = bone_matrix(87, player.bone_array, player.mesh);
    }
    else if (player.bone_count == 101) // female
    {
        bones.bone_neck = bone_matrix(21, player.bone_array, player.mesh);

        bones.bone_lshoulder = bone_matrix(23, player.bone_array, player.mesh);
        bones.bone_lelbow = bone_matrix(24, player.bone_array, player.mesh);
        bones.bone_lhand = bone_matrix(25, player.bone_array, player.mesh);

        bones.bone_rshoulder = bone_matrix(49, player.bone_array, player.mesh);
        bones.bone_relbow = bone_matrix(50, player.bone_array, player.mesh);
        bones.bone_rhand = bone_matrix(51, player.bone_array, player.mesh);

        bones.bone_lthigh = bone_matrix(75, player.bone_array, player.mesh);
        bones.bone_lknee = bone_matrix(76, player.bone_array, player.mesh);
        bones.bone_lfoot = bone_matrix(78, player.bone_array, player.mesh);

        bones.bone_rthigh = bone_matrix(82, player.bone_array, player.mesh);
        bones.bone_rknee = bone_matrix(83, player.bone_array, player.mesh);
        bones.bone_rfoot = bone_matrix(85, player.bone_array, player.mesh);
    }

    return bones;
}

inline void draw_line(float x1, float y1, float x2, float y2, ImU32 color, float thickness = 1.0f)
{
    ImGui::GetBackgroundDrawList()->AddLine(
        ImVec2(x1, y1),
        ImVec2(x2, y2),
        color,
        thickness
    );
}

inline void draw_skeleton(const Player& player)
{
    Bones bones = get_player_bones(player);

    // Convert to screen positions
    FVector2D neck = w2s(bones.bone_neck );
    FVector2D lShoulder = w2s(bones.bone_lshoulder  );
    FVector2D lElbow = w2s(bones.bone_lelbow  );
    FVector2D lHand = w2s(bones.bone_lhand  );

    FVector2D rShoulder = w2s(bones.bone_rshoulder );
    FVector2D rElbow = w2s(bones.bone_relbow );
    FVector2D rHand = w2s(bones.bone_rhand );

    FVector2D lThigh = w2s(bones.bone_lthigh );
    FVector2D lKnee = w2s(bones.bone_lknee );
    FVector2D lFoot = w2s(bones.bone_lfoot );

    FVector2D rThigh = w2s(bones.bone_rthigh );
    FVector2D rKnee = w2s(bones.bone_rknee );
    FVector2D rFoot = w2s(bones.bone_rfoot );

    // HEAD/NECK/SHOULDERS
    draw_line(neck.x, neck.y, lShoulder.x, lShoulder.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(neck.x, neck.y, rShoulder.x, rShoulder.y, ImColor(255,0,0, 250), 1.5f);

    // ARMS
    draw_line(lShoulder.x, lShoulder.y, lElbow.x, lElbow.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(lElbow.x, lElbow.y, lHand.x, lHand.y, ImColor(255,0,0, 250), 1.5f);

    draw_line(rShoulder.x, rShoulder.y, rElbow.x, rElbow.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(rElbow.x, rElbow.y, rHand.x, rHand.y, ImColor(255,0,0, 250), 1.5f);

    // SPINE (neck → hips = midpoint of thighs)
    FVector2D pelvis = { (lThigh.x + rThigh.x) * 0.5f, (lThigh.y + rThigh.y) * 0.5f };
    draw_line(neck.x, neck.y, pelvis.x, pelvis.y, ImColor(255,0,0, 250), 1.5f);

    // LEGS
    draw_line(pelvis.x, pelvis.y, lThigh.x, lThigh.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(lThigh.x, lThigh.y, lKnee.x, lKnee.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(lKnee.x, lKnee.y, lFoot.x, lFoot.y, ImColor(255,0,0, 250), 1.5f);

    draw_line(pelvis.x, pelvis.y, rThigh.x, rThigh.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(rThigh.x, rThigh.y, rKnee.x, rKnee.y, ImColor(255,0,0, 250), 1.5f);
    draw_line(rKnee.x, rKnee.y, rFoot.x, rFoot.y, ImColor(255,0,0, 250), 1.5f);
}

auto IsVisible(Player player) -> bool
{
    if (!player.mesh)
        return false;

    try {
        double fLastSubmitTime = km::RPM<double>(player.mesh + offsets::last_submit_time);
        double fLastRenderTimeOnScreen = km::RPM<double>(player.mesh + offsets::last_render_time);

        if (isnan(fLastSubmitTime) || isnan(fLastRenderTimeOnScreen) ||
            isinf(fLastSubmitTime) || isinf(fLastRenderTimeOnScreen))
            return false;

        const double fVisionTick = 0.06f;
        bool bVisible = fLastRenderTimeOnScreen + fVisionTick >= fLastSubmitTime;
        return bVisible;
    }
    catch (...) {

        return false;
    }
}


void aimbot(double targetX, double targetY)
{
    FVector2D head2d = FVector2D(targetX, targetY);
    FVector2D target{};

    if (head2d.x != 0)
    {
        if (head2d.x > center_x / 2)
        {
            target.x = -(center_x / 2 - head2d.x);
            target.x /= settings::smoothing;
            if (target.x + center_x / 2 > center_x) target.x = 0;
        }
        if (head2d.x < center_x / 2)
        {
            target.x = head2d.x - center_x / 2;
            target.x /= settings::smoothing;
            if (target.x + center_x / 2 < 0) target.x = 0;
        }
    }

    if (head2d.y != 0)
    {
        if (head2d.y > center_y / 2)
        {
            target.y = -(center_y / 2 - head2d.y);
            target.y /= settings::smoothing;
            if (target.y + center_y / 2 > center_y) target.y = 0;
        }
        if (head2d.y < center_y / 2)
        {
            target.y = head2d.y - center_y / 2;
            target.y /= settings::smoothing;
            if (target.y + center_y / 2 < 0) target.y = 0;
        }
    }


    km::mouse_mouse(target.x, target.y);
}
// for (int i = 0; i < Cache::actorcount; i++)

auto final::espaimloop() -> void	
{
    Player bestplayer;
    float distanc = FLT_MAX;
    std::lock_guard<std::mutex> lock(cacheMutex);
    for (const auto& player : playerCache)
    {
        FVector2D head2d = w2s(player.headPos);
        FVector2D bottom2d = w2s(player.rootPos);
        float box_height = abs(head2d.y - bottom2d.y);
        float box_width = box_height * 0.50f;

        if (settings::box)
        {
            draw_cornered_box(head2d.x - (box_width / 2), head2d.y, box_width, box_height + 4.f, ImColor(255, 0, 0, 250), 1);
        }

        if (settings::healthbar)
        {
            float box_h = bottom2d.y - head2d.y;
            float box_w = box_h / 2.0f;         // width of the player box
            float box_x = head2d.x - box_w / 2.0f;
            float box_y = head2d.y;

            // offset health bar to the left
            float healthbar_offset = 6.0f;      // distance from the box
            float healthbar_x = box_x - healthbar_offset;

            DrawHealthBar(player, healthbar_x, box_y, box_w, box_h);

        }

        if (settings::skeleton)
            draw_skeleton(player);

        if (settings::chinahat)
            DrawChinaHat(player.headPos, 25.f, 13.f, 16);

        if (settings::headdot)
        {
            ImGui::GetForegroundDrawList()->AddCircle(ImVec2(head2d.x, head2d.y),
                2.0f,
                IM_COL32(255, 255, 255, 255), 
                12,
                1.5f);
        }

        double dx = head2d.x - Width / 2;
        double dy = head2d.y - Height / 2;
        float dist = sqrtf(static_cast<float>(dx * dx + dy * dy));

        if (dist <= settings::fov && dist < distanc)
        {
            distanc = dist;
            bestplayer = player;
        }
	}
    if (settings::enabled && !settings::menu && distanc != FLT_MAX)
    {
        FVector2D head2d = w2s(bestplayer.headPos);
        if (GetAsyncKeyState(settings::key) & 0x8000)
        {
            if (settings::vischeck)   
                if (!IsVisible(bestplayer))
                    return;

            aimbot(head2d.x, head2d.y);
        }
    }
}


