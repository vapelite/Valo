#pragma once
#include <includes.h>

namespace cache
{
	void getworld();
	void cache();

}


namespace Cache
{
    inline uintptr_t gameInstance = 0;
    inline uintptr_t gameState = 0;
    inline uintptr_t level = 0;

    inline INT32 actorcount = 0;
    inline int peoplecount = 0;
    inline uintptr_t localPlayerArray = 0;
    inline uintptr_t localPlayer = 0;
    inline uintptr_t playerController = 0;
    inline uintptr_t localPawn = 0;
    inline uintptr_t playerState = 0;
    inline uintptr_t teamComponent = 0;
    inline int localTeamId = -1;

}