#include <loop/valhalla.h>
#include <random>

bool toggles[8] = {};
float slider1 = 1.0f, slider2 = 1.0f, slider3 = 1.0f;

static int keystatus = 0;
static int keystatus2 = 0;
namespace hotkeys
{
	int aimkey;
	int triggerkey;
}

void ChangeKey(void* blank)
{
	keystatus = 1;
	while (true)
	{
		for (int i = 0; i < 0x87; i++)
		{
			if (GetKeyState(i) & 0x8000)
			{
				settings::key = i;
				keystatus = 0;
				return;
			}
		}
	}
}

static const char* keyNames[] =
{
	(""),
	("Left Mouse"),
	("Right Mouse"),
	("Cancel"),
	("Middle Mouse"),
	("Mouse 5"),
	("Mouse 4"),
	(""),
	("Backspace"),
	("Tab"),
	(""),
	(""),
	("Clear"),
	("Enter"),
	(""),
	(""),
	("Shift"),
	("Control"),
	("Alt"),
	("Pause"),
	("Caps"),
	(""),
	(""),
	(""),
	(""),
	(""),
	(""),
	("Escape"),
	(""),
	(""),
	(""),
	(""),
	("Space"),
	("Page Up"),
	("Page Down"),
	("End"),
	("Home"),
	("Left"),
	("Up"),
	("Right"),
	("Down"),
	(""),
	(""),
	(""),
	("Print"),
	("Insert"),
	("Delete"),
	(""),
	("0"),
	("1"),
	("2"),
	("3"),
	("4"),
	("5"),
	("6"),
	("7"),
	("8"),
	("9"),
	(""),
	(""),
	(""),
	(""),
	(""),
	(""),
	(""),
	("A"),
	("B"),
	("C"),
	("D"),
	("E"),
	("F"),
	("G"),
	("H"),
	("I"),
	("J"),
	("K"),
	("L"),
	("M"),
	("N"),
	("O"),
	("P"),
	("Q"),
	("R"),
	("S"),
	("T"),
	("U"),
	("V"),
	("W"),
	("X"),
	("Y"),
	("Z"),
	(""),
	(""),
	(""),
	(""),
	(""),
	("Numpad 0"),
	("Numpad 1"),
	("Numpad 2"),
	("Numpad 3"),
	("Numpad 4"),
	("Numpad 5"),
	("Numpad 6"),
	("Numpad 7"),
	("Numpad 8"),
	("Numpad 9"),
	("Multiply"),
	("Add"),
	(""),
	("Subtract"),
	("Decimal"),
	("Divide"),
	("F1"),
	("F2"),
	("F3"),
	("F4"),
	("F5"),
	("F6"),
	("F7"),
	("F8"),
	("F9"),
	("F10"),
	("F11"),
	("F12")
};
static bool Items_ArrayGetter(void* data, int idx, const char** out_text)
{
	const char* const* items = (const char* const*)data;
	if (out_text)
		*out_text = items[idx];
	return true;
}
void HotkeyButton(int aimkey, void* changekey, int status)
{
	const char* preview_value = NULL;
	if (aimkey >= 0 && aimkey < IM_ARRAYSIZE(keyNames))
		Items_ArrayGetter(keyNames, aimkey, &preview_value);

	std::string aimkeys;
	if (preview_value == NULL)
		aimkeys = ("Select Key");
	else
		aimkeys = preview_value;

	if (status == 1)
	{
		aimkeys = ("Press the key");
	}
	if (ImGui::Button(aimkeys.c_str(), ImVec2(125, 25)))
	{
		if (status == 0)
		{
			CreateThread(0, 0, (LPTHREAD_START_ROUTINE)changekey, nullptr, 0, nullptr);
		}
	}
}

struct Snowflake {
	float x, y;         // Position of the snowflake
	float speed;        // Speed of the snowflake falling
	float size;         // Size of the snowflake
};


void render_snowflakes(bool menuVisible)
{
	static std::vector<Snowflake> snowflakes;
	static std::default_random_engine generator;
	static std::uniform_real_distribution<float> distributionX(0.0f, ImGui::GetIO().DisplaySize.x);
	static std::uniform_real_distribution<float> distributionSize(2.0f, 5.0f);
	static std::uniform_real_distribution<float> distributionSpeed(0.1f, 1.0f);

	if (menuVisible) {

		if (snowflakes.size() < 200) {
			snowflakes.push_back(Snowflake{
				distributionX(generator),
				0.0f,
				distributionSpeed(generator),
				distributionSize(generator)
				});
		}


		for (auto& snowflake : snowflakes) {
			snowflake.y += snowflake.speed;
			if (snowflake.y > ImGui::GetIO().DisplaySize.y) {
				snowflake.y = 0.0f;
			}

			// Draw snowflake as a small circle
			ImGui::GetForegroundDrawList()->AddCircleFilled(
				ImVec2(snowflake.x, snowflake.y),
				snowflake.size,
				IM_COL32(255, 255, 255, 255)
			);
		}
	}
	else {

		snowflakes.clear();
	}
}

namespace valhalla
{
	void input()
	{
		for (int i = 0; i < 5; i++) {
			ImGui::GetIO().MouseDown[i] = false;
		}

		int Button = -1;
		if (GetAsyncKeyState(VK_LBUTTON)) {
			Button = 0;
		}

		if (Button != -1) {
			ImGui::GetIO().MouseDown[Button] = true;
		}
	}

	int tab;
	const char* tabname = "Cheat";
	void drawmenu()
	{
		ImGui::SetNextWindowSize(ImVec2(500, 400));
		if (GetAsyncKeyState(VK_INSERT) & 1) settings::menu = !settings::menu;

		ImGui::Begin("valhalla", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
		{

			ImGui::Text(tabname);

	
			ImGui::Columns(2);
			ImGui::SetColumnWidth(0, 50.f);

			if (ImGui::Button("aim", ImVec2(40, 40)))
				tab = 1;

			if (ImGui::Button("esp", ImVec2(40, 40)))
				tab = 2;
			

			ImGui::NextColumn();
			{
				if (tab == 1)
				{
					ImGui::Checkbox("enable", &settings::enabled);
					ImGui::Checkbox("visible check", &settings::vischeck);
					ImGui::Checkbox("show fov", &settings::showfov);
					ImGui::SliderFloat("fov", &settings::fov, 0.f, 1800.f);
					ImGui::SliderFloat("smoothing", &settings::smoothing, 0, 30);
					HotkeyButton(settings::key, ChangeKey, keystatus);
				}

				if (tab == 2)
				{
					ImGui::Checkbox("corner box", &settings::box);
					ImGui::Checkbox("health bar", &settings::healthbar);
					ImGui::Checkbox("skeleton", &settings::skeleton);
					ImGui::Checkbox("china hat", &settings::chinahat);
					ImGui::Checkbox("headdot", &settings::headdot);
				}

				ImGui::Checkbox("team check", &settings::teamcheck);

				if (ImGui::Button("exit"))
				{
					exit(1);
				}
			}
		}

		ImGui::End();
	}


	void render()
	{
		if (!DirectX9.pDevice)
			return;

		// Toggle menu with Insert key
		if (GetAsyncKeyState(VK_INSERT) & 1)
			settings::menu = !settings::menu;

		ImGui_ImplDX9_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();
		final::espaimloop();
		//final::aimloop();

		if (settings::showfov)
		{
			ImGui::GetForegroundDrawList()->AddCircle(ImVec2(center_x / 2, center_y / 2), settings::fov, ImColor(255, 0, 0), 64, 0);
		}

		ImGui::GetIO().MouseDrawCursor = settings::menu;

		if (settings::menu) {
			ImGui::SetNextWindowBgAlpha(1.0f); // fully opaque
			ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 1.0f);

			input();
			drawmenu();

			SetWindowLong(Overlay.Hwnd, GWL_EXSTYLE, WS_EX_TOOLWINDOW);
			UpdateWindow(Overlay.Hwnd);
			SetFocus(Overlay.Hwnd);

			ImGui::PopStyleVar();
		}
		else {
			SetWindowLong(Overlay.Hwnd, GWL_EXSTYLE, WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW);
			SetFocus(nullptr);
		}

		ImGui::EndFrame();

		// DirectX rendering
		if (DirectX9.pDevice) {
			DirectX9.pDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0);
			if (DirectX9.pDevice->BeginScene() >= 0) {
				ImGui::Render();
				ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
				DirectX9.pDevice->EndScene();
			}

			HRESULT result = DirectX9.pDevice->Present(NULL, NULL, NULL, NULL);
			if (result == D3DERR_DEVICELOST && DirectX9.pDevice->TestCooperativeLevel() == D3DERR_DEVICENOTRESET) {
				ImGui_ImplDX9_InvalidateDeviceObjects();
				DirectX9.pDevice->Reset(&DirectX9.pParameters);
				ImGui_ImplDX9_CreateDeviceObjects();
			}
		}
	}



	void loop()
	{
		static RECT oldRect = { 0 };
		ZeroMemory(&DirectX9.Message, sizeof(MSG));

		// Initial overlay topmost setup
		SetWindowPos(Overlay.Hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);


		while (DirectX9.Message.message != WM_QUIT)
		{
			if (PeekMessage(&DirectX9.Message, Overlay.Hwnd, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&DirectX9.Message);
				DispatchMessage(&DirectX9.Message);
			}

			// Only check window size if it changed
			RECT rcWindow;
			GetWindowRect(Process.Hwnd, &rcWindow);

			if (memcmp(&rcWindow, &oldRect, sizeof(RECT)) != 0)
			{
				oldRect = rcWindow;

				// Move and resize overlay only if necessary
				SetWindowPos(
					Overlay.Hwnd,
					HWND_TOPMOST,
					rcWindow.left,
					rcWindow.top,
					rcWindow.right - rcWindow.left,
					rcWindow.bottom - rcWindow.top,
					SWP_NOACTIVATE | SWP_SHOWWINDOW
				);

				// Update DirectX backbuffer once
				if (DirectX9.pDevice)
				{
					DirectX9.pParameters.BackBufferWidth = rcWindow.right - rcWindow.left;
					DirectX9.pParameters.BackBufferHeight = rcWindow.bottom - rcWindow.top;
					DirectX9.pDevice->Reset(&DirectX9.pParameters);
				}
			}

			render(); // your ImGui rendering function
		}
	}
}