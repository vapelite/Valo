#pragma once
#include <includes.h>

namespace valhalla
{
	void render();
	void loop();
	void input();
}

namespace settings
{
	inline bool menu = false;
	inline bool teamcheck = false;

	inline bool box = false;
	inline bool skeleton = false;
	inline bool healthbar = false;
	inline bool chinahat = false;
	inline bool headdot = false;

	inline bool enabled = false;
	inline bool vischeck = false;
	inline bool showfov = false;
	inline float fov = 25;
	inline float smoothing;
	inline int key = 0x06;
}
